# Project TODO

- [x] Initialize Expo mobile project scaffold
- [x] Write mobile interface design plan
- [x] Define first-release scope around the AI command center
- [x] Generate and install custom DARK X AI app branding assets
- [x] Update app configuration with DARK X AI branding
- [x] Implement dark-first theme tokens and navigation surfaces
- [x] Implement Home command center with recent activity and quick actions
- [x] Implement local-first Chat flow with composer, context selector, and seeded response
- [x] Implement Projects surface with project cards and detail entry point
- [x] Implement Agents surface with approved-tool summaries and run status
- [x] Implement Settings surface with appearance and capability summaries
- [x] Add mobile interaction feedback and safe-area handling
- [x] Run TypeScript, lint, and test checks
- [x] Verify rendered mobile and desktop web previews
- [ ] Save final project checkpoint

## External service integration

- [x] Review attached external-service architecture requirements
- [x] Select modular AI provider and live-search provider
- [x] Configure required backend secrets through secure project settings
- [x] Implement provider abstraction and AI orchestration boundary
- [x] Implement live-search routing and source attribution
- [ ] Add streaming response transport between backend and mobile client
- [ ] Connect persistence, storage, and RAG-ready data boundaries where supported
- [x] Validate integration behavior and document credential setup

## Platform expansion from attached brief

- [x] Audit the current mobile scaffold against the full platform requirements
- [x] Define provider, model-router, agent, tool, and permission boundaries
- [x] Add persistent conversations, messages, projects, files, usage, and execution records
- [x] Add RAG-ready file metadata, chunk, embedding, and retrieval boundaries
- [ ] Add streaming-friendly status events without exposing hidden reasoning
- [x] Add safe agent execution metadata and approved-tool registry
- [ ] Expand the mobile chat experience with model, attachment, source, and activity states
- [x] Validate the expanded platform slice and update setup documentation

## Authenticated history and model selection

- [x] Add authenticated conversation-history and model-catalog checklist items
- [x] Connect protected history queries to the mobile client
- [x] Add authenticated sign-in state and protected-route handling in the UI
- [x] Add model-selection UI and pass the selected model through the AI route
- [x] Add history selection, new-conversation, and empty-state flows
- [x] Validate authenticated history and model-selection behavior

## Advanced chat experience

- [x] Audit and replace non-functional chat actions
- [ ] Render AI markdown with readable headings, lists, quotes, links, and code blocks
- [ ] Add working copy, regenerate, retry, share, read-aloud, and feedback actions
- [ ] Add searchable authenticated conversation history with rename, archive, and delete behavior
- [x] Add model selection and visible model state in the composer
- [ ] Add attachment-ready composer states without claiming uploads that are not complete
- [ ] Add stop/cancel contract for future streaming transport
- [x] Validate advanced chat interactions and update documentation

## Mobile bug-fix and interaction hardening

- [ ] Audit startup, auth initialization, router state, and unhandled errors
- [ ] Add guarded Android Back handling for root, chat, drawer, modal, and keyboard states
- [ ] Centralize view navigation and prevent accidental route/history changes
- [ ] Harden chat loading, error, retry, stop, resend, and draft-preservation states
- [ ] Add safe markdown/code rendering boundaries and mobile overflow handling
- [ ] Harden attachment affordances so unsupported or incomplete upload paths are explicit
- [ ] Audit all visible interactive controls for valid actions and touch feedback
- [ ] Add loading, empty, error, and retry states for important queries
- [ ] Validate Android-oriented layouts and navigation behavior
