import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import {
  Alert,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Share,
} from "react-native";
import * as Clipboard from "expo-clipboard";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/hooks/use-auth";
import { startOAuthLogin } from "@/constants/oauth";

type ViewKey = "home" | "chat" | "projects" | "agents" | "settings";
type Message = { id: string; role: "user" | "assistant"; text: string; sources?: string[] };

const suggestedPrompts = [
  { icon: "bolt", title: "Plan a launch", text: "Build a clear launch plan for my next product." },
  { icon: "travel-explore", title: "Research live", text: "Find the latest signals shaping AI product design." },
  { icon: "folder-open", title: "Use a project", text: "Help me organize the next steps for a project." },
];

const projects = [
  { name: "Product strategy", meta: "12 conversations · 8 files", tone: "violet", icon: "insights" },
  { name: "Research desk", meta: "6 conversations · Live sources", tone: "cyan", icon: "travel-explore" },
  { name: "Personal systems", meta: "4 conversations · 2 agents", tone: "mint", icon: "auto-awesome" },
];

const agents = [
  { name: "Research analyst", description: "Finds, filters, and cites recent information.", tools: "Web search · URL retrieval", icon: "travel-explore", color: "#22D3EE" },
  { name: "Project operator", description: "Turns context into a verified action plan.", tools: "Projects · Files · Planner", icon: "account-tree", color: "#8B5CF6" },
  { name: "Clarity editor", description: "Shapes rough thinking into concise output.", tools: "Documents · Formatter", icon: "edit-note", color: "#34D399" },
];

export default function HomeScreen() {
  const colors = useColors("dark");
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [activeView, setActiveView] = useState<ViewKey>("home");
  const [historyOpen, setHistoryOpen] = useState(false);
  const [modelOpen, setModelOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState("");
  const [selectedConversationId, setSelectedConversationId] = useState(0);
  const [composer, setComposer] = useState("");
  const [selectedContext, setSelectedContext] = useState("No context");
  const [messages, setMessages] = useState<Message[]>([
    { id: "welcome", role: "assistant", text: "Welcome to DARK X AI. I can help you think, research, and move work forward." },
  ]);
  const [isGenerating, setIsGenerating] = useState(false);
  const answerMutation = trpc.ai.answer.useMutation();
  const modelQuery = trpc.ai.models.useQuery();
  const historyQuery = trpc.conversations.list.useQuery(undefined, { enabled: isAuthenticated && activeView === "chat" });
  const messagesQuery = trpc.conversations.messages.useQuery({ conversationId: selectedConversationId || 1 }, { enabled: isAuthenticated && selectedConversationId > 0 });

  useEffect(() => {
    if (!selectedModel && modelQuery.data?.length) setSelectedModel(modelQuery.data[0].id);
  }, [modelQuery.data, selectedModel]);

  useEffect(() => {
    if (messagesQuery.data && selectedConversationId > 0) {
      setMessages(messagesQuery.data.map(({ message }) => ({ id: String(message.id), role: message.role === "user" ? "user" : "assistant", text: message.content, sources: message.sourcesJson ? JSON.parse(message.sourcesJson).map((source: { title?: string }) => source.title ?? "Source") : undefined })));
    }
  }, [messagesQuery.data, selectedConversationId]);

  const sendMessage = async (text = composer) => {
    const trimmed = text.trim();
    if (!trimmed || isGenerating) return;
    setMessages((current) => [...current, { id: `${Date.now()}-user`, role: "user", text: trimmed }]);
    setComposer("");
    setActiveView("chat");
    setIsGenerating(true);
    try {
      const result = await answerMutation.mutateAsync({ message: trimmed, context: selectedContext === "No context" ? undefined : selectedContext, model: selectedModel || undefined, conversationId: selectedConversationId || undefined });
      setSelectedConversationId(result.conversationId ?? selectedConversationId);
      setMessages((current) => [...current, { id: `${Date.now()}-assistant`, role: "assistant", text: result.answer, sources: result.sources.map((source) => source.title) }]);
    } catch (error) {
      const detail = error instanceof Error ? error.message : "The AI service could not complete this request.";
      setMessages((current) => [...current, { id: `${Date.now()}-error`, role: "assistant", text: `I couldn’t complete that request. ${detail}` }]);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyMessage = async (text: string) => {
    try {
      await Clipboard.setStringAsync(text);
      Alert.alert("Copied", "The response is ready on your clipboard.");
    } catch {
      Alert.alert("Copy unavailable", "Your device did not allow clipboard access.");
    }
  };

  const shareMessage = async (text: string) => {
    try {
      await Share.share({ message: text });
    } catch {
      Alert.alert("Share unavailable", "The response could not be shared from this device.");
    }
  };

  const regenerateLast = () => {
    const lastUserMessage = [...messages].reverse().find((item) => item.role === "user");
    if (lastUserMessage) sendMessage(lastUserMessage.text);
  };

  const navItems: { key: ViewKey; label: string; icon: keyof typeof MaterialIcons.glyphMap }[] = [
    { key: "home", label: "Home", icon: "home" },
    { key: "chat", label: "Chat", icon: "chat-bubble-outline" },
    { key: "projects", label: "Projects", icon: "folder-open" },
    { key: "agents", label: "Agents", icon: "hub" },
    { key: "settings", label: "Settings", icon: "tune" },
  ];

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} containerClassName="bg-background">
      <View style={styles.shell}>
        <View style={styles.topBar}>
          <View style={styles.brandRow}>
            <View style={styles.brandMark}><Text style={styles.brandX}>×</Text></View>
            <View><Text style={styles.brandName}>DARK X AI</Text><Text style={styles.brandCaption}>INTELLIGENCE WORKSPACE</Text></View>
          </View>
          <Pressable accessibilityLabel="Notifications" style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]} onPress={() => Alert.alert("All clear", "No new workspace notifications.")}>
            <MaterialIcons name="notifications-none" size={21} color="#94A3B8" />
            <View style={styles.notificationDot} />
          </Pressable>
        </View>

        <View style={styles.content}>
          {activeView === "home" && (
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
              <Text style={styles.eyebrow}>THURSDAY, SEPTEMBER 5</Text>
              <Text style={styles.title}>Good evening, Alex.</Text>
              <Text style={styles.subtitle}>Your thinking space is ready.</Text>

              <Pressable accessibilityLabel="Start a new conversation" style={({ pressed }) => [styles.heroCard, pressed && styles.pressed]} onPress={() => setActiveView("chat")}>
                <View style={styles.heroGlow} />
                <View style={styles.heroIcon}><MaterialIcons name="auto-awesome" size={22} color="#EDE9FE" /></View>
                <View style={styles.heroCopy}><Text style={styles.heroTitle}>Start with a thought</Text><Text style={styles.heroSubtitle}>Ask anything. Bring your context.</Text></View>
                <MaterialIcons name="arrow-forward" size={21} color="#C4B5FD" />
              </Pressable>

              <SectionHeader title="Suggested starts" action="View all" onPress={() => setActiveView("chat")} />
              <View style={styles.promptGrid}>{suggestedPrompts.map((prompt) => (
                <Pressable key={prompt.title} accessibilityLabel={prompt.title} style={({ pressed }) => [styles.promptCard, pressed && styles.pressed]} onPress={() => sendMessage(prompt.text)}>
                  <MaterialIcons name={prompt.icon as keyof typeof MaterialIcons.glyphMap} size={20} color="#8B5CF6" />
                  <Text style={styles.promptTitle}>{prompt.title}</Text><Text style={styles.promptText}>{prompt.text}</Text>
                </Pressable>
              ))}</View>

              <SectionHeader title="Active workspace" action="Manage" onPress={() => setActiveView("projects")} />
              <View style={styles.workspaceCard}><View style={styles.workspaceIcon}><MaterialIcons name="layers" size={18} color="#22D3EE" /></View><View style={{ flex: 1 }}><Text style={styles.cardTitle}>Personal workspace</Text><Text style={styles.cardMeta}>Context is private to you · Synced locally</Text></View><MaterialIcons name="chevron-right" size={20} color="#64748B" /></View>

              <SectionHeader title="Recent thinking" action="See history" onPress={() => setActiveView("chat")} />
              {[
                ["Designing an AI-first workflow", "Today · 8 messages", "auto-awesome"],
                ["Notes from the research desk", "Yesterday · 14 messages", "travel-explore"],
              ].map(([title, meta, icon]) => <Pressable key={title} style={({ pressed }) => [styles.recentRow, pressed && styles.pressed]} onPress={() => setActiveView("chat")}><View style={styles.recentIcon}><MaterialIcons name={icon as keyof typeof MaterialIcons.glyphMap} size={18} color="#94A3B8" /></View><View style={{ flex: 1 }}><Text style={styles.cardTitle}>{title}</Text><Text style={styles.cardMeta}>{meta}</Text></View><MaterialIcons name="more-horiz" size={19} color="#64748B" /></Pressable>)}
            </ScrollView>
          )}

          {activeView === "chat" && <ChatView colors={colors} composer={composer} setComposer={setComposer} messages={messages} sendMessage={sendMessage} selectedContext={selectedContext} setSelectedContext={setSelectedContext} isGenerating={isGenerating} selectedModel={selectedModel} setSelectedModel={setSelectedModel} models={modelQuery.data ?? []} historyOpen={historyOpen} setHistoryOpen={setHistoryOpen} modelOpen={modelOpen} setModelOpen={setModelOpen} history={historyQuery.data ?? []} isAuthenticated={isAuthenticated} authLoading={authLoading} user={user} onLogin={startOAuthLogin} onSelectConversation={(id: number) => { setSelectedConversationId(id); setHistoryOpen(false); }} onNewConversation={() => { setSelectedConversationId(0); setMessages([{ id: "welcome", role: "assistant", text: "Welcome to DARK X AI. What are we building today?" }]); setHistoryOpen(false); }} onCopy={copyMessage} onShare={shareMessage} onRegenerate={regenerateLast} />}
          {activeView === "projects" && <ProjectsView onOpenChat={() => setActiveView("chat")} />}
          {activeView === "agents" && <AgentsView onRun={() => { setActiveView("chat"); sendMessage("Run a research pass on my current workspace."); }} />}
          {activeView === "settings" && <SettingsView />}
        </View>

        <View style={styles.bottomNav}>{navItems.map((item) => <Pressable key={item.key} accessibilityRole="button" accessibilityState={{ selected: activeView === item.key }} style={({ pressed }) => [styles.navItem, pressed && styles.pressed]} onPress={() => setActiveView(item.key)}><MaterialIcons name={item.icon} size={21} color={activeView === item.key ? "#C4B5FD" : "#64748B"} /><Text style={[styles.navLabel, activeView === item.key && styles.navLabelActive]}>{item.label}</Text></Pressable>)}</View>
      </View>
    </ScreenContainer>
  );
}

function SectionHeader({ title, action, onPress }: { title: string; action: string; onPress: () => void }) { return <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>{title}</Text><Pressable onPress={onPress} style={({ pressed }) => pressed && styles.pressed}><Text style={styles.sectionAction}>{action}</Text></Pressable></View>; }

function ChatView({ colors, composer, setComposer, messages, sendMessage, selectedContext, setSelectedContext, isGenerating, selectedModel, setSelectedModel, models, historyOpen, setHistoryOpen, modelOpen, setModelOpen, history, isAuthenticated, authLoading, user, onLogin, onSelectConversation, onNewConversation, onCopy, onShare, onRegenerate }: any) {
  return <View style={styles.chatWrap}>
    <View style={styles.chatHeader}>
      <View style={{ flex: 1 }}><Text style={styles.eyebrow}>PRIVATE WORKSPACE</Text><Text style={styles.chatTitle}>New conversation</Text><Text style={styles.authMeta}>{authLoading ? "Checking account…" : isAuthenticated ? `Signed in as ${user?.name || user?.email || "you"}` : "Sign in to sync history"}</Text></View>
      <View style={styles.headerActions}>
        <Pressable accessibilityLabel="Conversation history" style={({ pressed }) => [styles.headerAction, pressed && styles.pressed]} onPress={() => setHistoryOpen(!historyOpen)}><MaterialIcons name="history" size={19} color="#C4B5FD" /></Pressable>
        <Pressable style={({ pressed }) => [styles.contextPill, pressed && styles.pressed]} onPress={() => setSelectedContext(selectedContext === "No context" ? "Personal workspace" : "No context")}><MaterialIcons name="layers" size={15} color="#22D3EE" /><Text style={styles.contextText}>{selectedContext}</Text><MaterialIcons name="expand-more" size={16} color="#64748B" /></Pressable>
      </View>
    </View>
    {historyOpen && <HistoryDrawer history={history} isAuthenticated={isAuthenticated} onLogin={onLogin} onSelectConversation={onSelectConversation} onNewConversation={onNewConversation} />}
    {modelOpen && <ModelPicker models={models} selectedModel={selectedModel} onSelect={(id: string) => { setSelectedModel(id); setModelOpen(false); }} />}
    <FlatList data={messages} keyExtractor={(item: Message) => item.id} contentContainerStyle={styles.messageList} renderItem={({ item }) => <View style={[styles.messageRow, item.role === "user" && styles.messageRowUser]}><View style={[styles.avatar, item.role === "user" ? styles.userAvatar : styles.aiAvatar]}><MaterialIcons name={item.role === "user" ? "person" : "auto-awesome"} size={16} color={item.role === "user" ? "#CBD5E1" : "#C4B5FD"} /></View><View style={[styles.messageBubble, item.role === "user" ? styles.userBubble : styles.aiBubble]}><Text style={styles.messageText}>{item.text}</Text>{item.sources?.map((source: string) => <Pressable key={source} style={styles.sourceChip} onPress={() => Alert.alert("Source", source)}><MaterialIcons name="verified" size={13} color="#22D3EE" /><Text style={styles.sourceText}>{source}</Text></Pressable>)}{item.role === "assistant" && item.id !== "welcome" && <View style={styles.messageActions}><Pressable accessibilityLabel="Copy response" onPress={() => onCopy(item.text)} style={styles.messageAction}><MaterialIcons name="content-copy" size={14} color="#94A3B8" /></Pressable><Pressable accessibilityLabel="Regenerate response" onPress={onRegenerate} style={styles.messageAction}><MaterialIcons name="refresh" size={15} color="#94A3B8" /></Pressable><Pressable accessibilityLabel="Share response" onPress={() => onShare(item.text)} style={styles.messageAction}><MaterialIcons name="ios-share" size={15} color="#94A3B8" /></Pressable></View>}</View></View>} ListFooterComponent={isGenerating ? <View style={styles.processingRow}><MaterialIcons name="auto-awesome" size={14} color="#A78BFA" /><Text style={styles.processingText}>Preparing answer and checking context…</Text></View> : null} ListEmptyComponent={<Text style={styles.emptyText}>Your next idea starts here.</Text>} />
    <View style={styles.composerCard}><TextInput accessibilityLabel="Message DARK X AI" placeholder="Ask DARK X AI anything..." placeholderTextColor="#64748B" value={composer} onChangeText={setComposer} multiline style={styles.input} onSubmitEditing={() => sendMessage()} /><View style={styles.composerActions}><Pressable accessibilityLabel="Attach context" style={({ pressed }) => [styles.smallAction, pressed && styles.pressed]} onPress={() => setSelectedContext(selectedContext === "No context" ? "Personal workspace" : "No context")}><MaterialIcons name="attach-file" size={19} color="#94A3B8" /></Pressable><Pressable accessibilityLabel="Select model" style={({ pressed }) => [styles.modelSelector, pressed && styles.pressed]} onPress={() => setModelOpen(!modelOpen)}><Text numberOfLines={1} style={styles.modelLabel}>{models.find((model: { id: string }) => model.id === selectedModel)?.id || "Default model"}</Text><MaterialIcons name="expand-more" size={15} color="#94A3B8" /></Pressable><Pressable accessibilityLabel="Send message" style={({ pressed }) => [styles.sendButton, pressed && styles.pressed]} onPress={() => sendMessage()}><MaterialIcons name="arrow-upward" size={19} color="#080B12" /></Pressable></View></View>
  </View>;
}

function HistoryDrawer({ history, isAuthenticated, authLoading, onLogin, onSelectConversation, onNewConversation }: any) {
  const [query, setQuery] = useState("");
  const filtered = history.filter((item: { title: string }) => item.title.toLowerCase().includes(query.toLowerCase()));
  return <View style={styles.historyDrawer}><View style={styles.drawerHeader}><View><Text style={styles.drawerTitle}>Conversation history</Text><Text style={styles.cardMeta}>{isAuthenticated ? "Synced to your account" : "Private until you sign in"}</Text></View><Pressable accessibilityLabel="New conversation" style={({ pressed }) => [styles.newConversation, pressed && styles.pressed]} onPress={onNewConversation}><MaterialIcons name="add" size={17} color="#EDE9FE" /></Pressable></View>{isAuthenticated && <TextInput accessibilityLabel="Search conversations" placeholder="Search conversations" placeholderTextColor="#64748B" value={query} onChangeText={setQuery} style={styles.historySearch} />}{authLoading ? <Text style={styles.emptyText}>Checking your session…</Text> : !isAuthenticated ? <View style={styles.signInCard}><MaterialIcons name="lock-outline" size={19} color="#A78BFA" /><Text style={styles.signInText}>Sign in to browse and continue previous conversations.</Text><Pressable style={({ pressed }) => [styles.signInButton, pressed && styles.pressed]} onPress={onLogin}><Text style={styles.signInButtonText}>Sign in</Text></Pressable></View> : filtered.length === 0 ? <Text style={styles.emptyText}>No matching conversations.</Text> : <View style={styles.historyList}>{filtered.slice(0, 8).map((item: { id: number; title: string; updatedAt: string }) => <Pressable key={item.id} style={({ pressed }) => [styles.historyRow, pressed && styles.pressed]} onPress={() => onSelectConversation(item.id)}><View style={styles.recentIcon}><MaterialIcons name="chat-bubble-outline" size={16} color="#94A3B8" /></View><View style={{ flex: 1 }}><Text numberOfLines={1} style={styles.cardTitle}>{item.title}</Text><Text style={styles.cardMeta}>{new Date(item.updatedAt).toLocaleDateString()}</Text></View><MaterialIcons name="chevron-right" size={18} color="#64748B" /></Pressable>)}</View>}</View>;
}

function ModelPicker({ models, selectedModel, onSelect }: any) {
  return <View style={styles.modelPicker}><View style={styles.drawerHeader}><View><Text style={styles.drawerTitle}>Choose a model</Text><Text style={styles.cardMeta}>Your selection applies to the next answer.</Text></View><MaterialIcons name="tune" size={18} color="#A78BFA" /></View>{models.length === 0 ? <Text style={styles.emptyText}>Loading available models…</Text> : <View style={styles.historyList}>{models.slice(0, 8).map((model: { id: string; ownedBy?: string }) => <Pressable key={model.id} style={({ pressed }) => [styles.modelRow, pressed && styles.pressed]} onPress={() => onSelect(model.id)}><View style={[styles.modelRadio, selectedModel === model.id && styles.modelRadioActive]}>{selectedModel === model.id && <View style={styles.modelRadioDot} />}</View><View style={{ flex: 1 }}><Text style={styles.cardTitle}>{model.id}</Text><Text style={styles.cardMeta}>{model.ownedBy || "DARK X AI provider"}</Text></View></Pressable>)}</View>}</View>;
}

function ProjectsView({ onOpenChat }: { onOpenChat: () => void }) { return <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}><Text style={styles.eyebrow}>WORKSPACES</Text><Text style={styles.title}>Projects</Text><Text style={styles.subtitle}>Keep context close to the work.</Text><Pressable style={({ pressed }) => [styles.newProject, pressed && styles.pressed]} onPress={onOpenChat}><MaterialIcons name="add" size={18} color="#EDE9FE" /><Text style={styles.newProjectText}>Start project conversation</Text></Pressable><View style={{ gap: 12, marginTop: 20 }}>{projects.map((project) => <Pressable key={project.name} style={({ pressed }) => [styles.projectCard, pressed && styles.pressed]} onPress={onOpenChat}><View style={[styles.projectIcon, { backgroundColor: project.tone === "violet" ? "#2A1A52" : project.tone === "cyan" ? "#10333D" : "#12362E" }]}><MaterialIcons name={project.icon as keyof typeof MaterialIcons.glyphMap} size={21} color={project.tone === "violet" ? "#C4B5FD" : project.tone === "cyan" ? "#67E8F9" : "#6EE7B7"} /></View><View style={{ flex: 1 }}><Text style={styles.cardTitle}>{project.name}</Text><Text style={styles.cardMeta}>{project.meta}</Text><Text style={styles.projectStatus}>Ready for context</Text></View><MaterialIcons name="chevron-right" size={20} color="#64748B" /></Pressable>)}</View></ScrollView>; }

function AgentsView({ onRun }: { onRun: () => void }) { return <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}><Text style={styles.eyebrow}>TOOL-AWARE INTELLIGENCE</Text><Text style={styles.title}>Agents</Text><Text style={styles.subtitle}>Focused help, with visible boundaries.</Text><View style={styles.safetyNote}><MaterialIcons name="verified-user" size={18} color="#34D399" /><Text style={styles.safetyText}>Agents only run approved tools. Progress is visible; private reasoning stays private.</Text></View><View style={{ gap: 12, marginTop: 20 }}>{agents.map((agent) => <Pressable key={agent.name} style={({ pressed }) => [styles.agentCard, pressed && styles.pressed]} onPress={onRun}><View style={[styles.agentIcon, { backgroundColor: `${agent.color}1A` }]}><MaterialIcons name={agent.icon as keyof typeof MaterialIcons.glyphMap} size={21} color={agent.color} /></View><View style={{ flex: 1 }}><Text style={styles.cardTitle}>{agent.name}</Text><Text style={styles.agentDescription}>{agent.description}</Text><Text style={[styles.agentTools, { color: agent.color }]}>{agent.tools}</Text></View><MaterialIcons name="play-circle-outline" size={23} color="#94A3B8" /></Pressable>)}</View></ScrollView>; }

function SettingsView() { return <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}><Text style={styles.eyebrow}>CONTROL PLANE</Text><Text style={styles.title}>Settings</Text><Text style={styles.subtitle}>Make the workspace feel like yours.</Text><View style={styles.profileCard}><View style={styles.profileAvatar}><Text style={styles.profileInitial}>A</Text></View><View style={{ flex: 1 }}><Text style={styles.cardTitle}>Alex Morgan</Text><Text style={styles.cardMeta}>Personal workspace · Local session</Text></View><MaterialIcons name="chevron-right" size={20} color="#64748B" /></View><View style={styles.settingsGroup}>{[["palette", "Appearance", "Dark mode · Midnight"], ["psychology", "Default model", "Reasoning · Balanced"], ["memory", "Memory", "User controlled"], ["security", "Privacy & security", "Protected locally"]].map(([icon, title, meta]) => <Pressable key={title} style={({ pressed }) => [styles.settingRow, pressed && styles.pressed]} onPress={() => Alert.alert(title, `${meta}. This control is ready for your next configuration step.`)}><View style={styles.settingIcon}><MaterialIcons name={icon as keyof typeof MaterialIcons.glyphMap} size={19} color="#94A3B8" /></View><View style={{ flex: 1 }}><Text style={styles.cardTitle}>{title}</Text><Text style={styles.cardMeta}>{meta}</Text></View><MaterialIcons name="chevron-right" size={20} color="#64748B" /></Pressable>)}</View></ScrollView>; }

const styles = StyleSheet.create({
  shell: { flex: 1, backgroundColor: "#080B12" }, topBar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: 10, paddingBottom: 18 }, brandRow: { flexDirection: "row", alignItems: "center", gap: 10 }, brandMark: { width: 34, height: 34, borderRadius: 10, backgroundColor: "#1C1535", borderWidth: 1, borderColor: "#4C3B80", alignItems: "center", justifyContent: "center" }, brandX: { color: "#C4B5FD", fontSize: 26, fontWeight: "700", lineHeight: 29 }, brandName: { color: "#F4F7FB", fontSize: 13, fontWeight: "800", letterSpacing: 2 }, brandCaption: { color: "#64748B", fontSize: 8, fontWeight: "700", letterSpacing: 1.2, marginTop: 2 }, iconButton: { width: 38, height: 38, borderRadius: 12, backgroundColor: "#111827", borderWidth: 1, borderColor: "#25324A", alignItems: "center", justifyContent: "center" }, notificationDot: { position: "absolute", top: 9, right: 10, width: 5, height: 5, borderRadius: 3, backgroundColor: "#22D3EE" }, content: { flex: 1 }, scrollContent: { paddingHorizontal: 20, paddingBottom: 28 }, eyebrow: { color: "#64748B", fontSize: 10, fontWeight: "800", letterSpacing: 1.4, marginTop: 4, marginBottom: 8 }, title: { color: "#F4F7FB", fontSize: 30, lineHeight: 37, fontWeight: "800", letterSpacing: -0.7 }, subtitle: { color: "#94A3B8", fontSize: 15, marginTop: 5, marginBottom: 22 }, heroCard: { overflow: "hidden", flexDirection: "row", alignItems: "center", backgroundColor: "#17112B", borderRadius: 20, padding: 16, borderWidth: 1, borderColor: "#463681", marginBottom: 24 }, heroGlow: { position: "absolute", width: 120, height: 120, borderRadius: 60, backgroundColor: "#35206A", opacity: 0.45, right: -20, top: -40 }, heroIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#6D45D5", alignItems: "center", justifyContent: "center", marginRight: 12 }, heroCopy: { flex: 1 }, heroTitle: { color: "#F5F3FF", fontSize: 16, fontWeight: "700" }, heroSubtitle: { color: "#B8A9E8", fontSize: 13, marginTop: 3 }, sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }, sectionTitle: { color: "#E2E8F0", fontSize: 16, fontWeight: "700" }, sectionAction: { color: "#A78BFA", fontSize: 12, fontWeight: "700" }, promptGrid: { gap: 10, marginBottom: 24 }, promptCard: { width: "100%", backgroundColor: "#111827", borderRadius: 16, borderWidth: 1, borderColor: "#25324A", padding: 15 }, promptTitle: { color: "#E2E8F0", fontSize: 14, fontWeight: "700", marginTop: 10 }, promptText: { color: "#94A3B8", fontSize: 13, lineHeight: 19, marginTop: 4, maxWidth: "90%" }, workspaceCard: { flexDirection: "row", alignItems: "center", backgroundColor: "#0E1824", borderRadius: 16, borderWidth: 1, borderColor: "#1E4053", padding: 14, marginBottom: 24 }, workspaceIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: "#12303D", alignItems: "center", justifyContent: "center", marginRight: 11 }, cardTitle: { color: "#E2E8F0", fontSize: 14, fontWeight: "700" }, cardMeta: { color: "#718096", fontSize: 12, marginTop: 4 }, recentRow: { flexDirection: "row", alignItems: "center", paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: "#172033" }, recentIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: "#111827", alignItems: "center", justifyContent: "center", marginRight: 11 }, bottomNav: { flexDirection: "row", justifyContent: "space-around", paddingTop: 11, paddingBottom: 7, borderTopWidth: 1, borderTopColor: "#172033", backgroundColor: "#0B0F18" }, navItem: { alignItems: "center", gap: 3, paddingHorizontal: 8, paddingVertical: 3 }, navLabel: { color: "#64748B", fontSize: 10, fontWeight: "600" }, navLabelActive: { color: "#C4B5FD" }, pressed: { opacity: 0.7, transform: [{ scale: 0.98 }] }, chatWrap: { flex: 1 }, chatHeader: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", paddingHorizontal: 20, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: "#172033" }, chatTitle: { color: "#F4F7FB", fontSize: 23, fontWeight: "800" }, contextPill: { flexDirection: "row", alignItems: "center", gap: 5, maxWidth: 150, backgroundColor: "#0E1824", borderRadius: 12, borderWidth: 1, borderColor: "#1E4053", paddingHorizontal: 9, paddingVertical: 8 }, contextText: { color: "#A5F3FC", fontSize: 11, flexShrink: 1 }, messageList: { padding: 20, gap: 16, paddingBottom: 12 }, messageRow: { flexDirection: "row", alignItems: "flex-start", gap: 9 }, messageRowUser: { flexDirection: "row-reverse" }, avatar: { width: 28, height: 28, borderRadius: 10, alignItems: "center", justifyContent: "center", marginTop: 2 }, aiAvatar: { backgroundColor: "#211743" }, userAvatar: { backgroundColor: "#1E293B" }, messageBubble: { maxWidth: "82%", padding: 13, borderRadius: 16 }, aiBubble: { backgroundColor: "#111827", borderTopLeftRadius: 4, borderWidth: 1, borderColor: "#25324A" }, userBubble: { backgroundColor: "#2A1A52", borderTopRightRadius: 4 }, messageText: { color: "#E2E8F0", fontSize: 15, lineHeight: 22 }, sourceChip: { flexDirection: "row", alignItems: "center", gap: 5, alignSelf: "flex-start", marginTop: 11, paddingHorizontal: 8, paddingVertical: 5, borderRadius: 8, backgroundColor: "#0C2430" }, sourceText: { color: "#67E8F9", fontSize: 11 }, emptyText: { color: "#64748B", textAlign: "center", marginTop: 40 }, composerCard: { margin: 16, marginTop: 4, backgroundColor: "#111827", borderRadius: 18, borderWidth: 1, borderColor: "#334155", padding: 12 }, input: { color: "#F4F7FB", fontSize: 15, minHeight: 44, maxHeight: 100, textAlignVertical: "top", paddingTop: 3 }, composerActions: { flexDirection: "row", alignItems: "center", marginTop: 8 }, smallAction: { width: 30, height: 30, alignItems: "center", justifyContent: "center" }, modelLabel: { color: "#64748B", fontSize: 11, flex: 1, marginLeft: 3 }, sendButton: { width: 34, height: 34, borderRadius: 12, backgroundColor: "#A78BFA", alignItems: "center", justifyContent: "center" }, newProject: { flexDirection: "row", alignItems: "center", alignSelf: "flex-start", gap: 7, backgroundColor: "#6D45D5", borderRadius: 12, paddingHorizontal: 13, paddingVertical: 11 }, newProjectText: { color: "#F5F3FF", fontSize: 13, fontWeight: "700" }, projectCard: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#111827", borderRadius: 17, borderWidth: 1, borderColor: "#25324A", padding: 14 }, projectIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }, projectStatus: { color: "#64748B", fontSize: 11, marginTop: 8 }, safetyNote: { flexDirection: "row", alignItems: "flex-start", gap: 9, backgroundColor: "#0D211C", borderWidth: 1, borderColor: "#1D4D3F", borderRadius: 14, padding: 12 }, safetyText: { color: "#A7F3D0", fontSize: 12, lineHeight: 18, flex: 1 }, agentCard: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#111827", borderRadius: 17, borderWidth: 1, borderColor: "#25324A", padding: 14 }, agentIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }, agentDescription: { color: "#94A3B8", fontSize: 12, lineHeight: 17, marginTop: 4 }, agentTools: { fontSize: 11, marginTop: 8, fontWeight: "700" }, profileCard: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#111827", borderRadius: 17, borderWidth: 1, borderColor: "#25324A", padding: 14, marginBottom: 18 }, profileAvatar: { width: 42, height: 42, borderRadius: 15, backgroundColor: "#2A1A52", alignItems: "center", justifyContent: "center" }, profileInitial: { color: "#C4B5FD", fontSize: 18, fontWeight: "800" }, settingsGroup: { backgroundColor: "#111827", borderRadius: 17, borderWidth: 1, borderColor: "#25324A", overflow: "hidden" }, settingRow: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14, borderBottomWidth: 1, borderBottomColor: "#1C283C" }, settingIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: "#1B2435", alignItems: "center", justifyContent: "center" }, authMeta: { color: "#64748B", fontSize: 11, marginTop: 4 }, headerActions: { flexDirection: "row", alignItems: "center", gap: 8, marginLeft: 10 }, headerAction: { width: 34, height: 34, borderRadius: 11, backgroundColor: "#111827", borderWidth: 1, borderColor: "#25324A", alignItems: "center", justifyContent: "center" }, modelSelector: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, minWidth: 0, paddingHorizontal: 4 }, historyDrawer: { marginHorizontal: 16, marginTop: 10, backgroundColor: "#0F1724", borderRadius: 16, borderWidth: 1, borderColor: "#25324A", padding: 12 }, modelPicker: { marginHorizontal: 16, marginTop: 10, backgroundColor: "#0F1724", borderRadius: 16, borderWidth: 1, borderColor: "#25324A", padding: 12 }, drawerHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }, drawerTitle: { color: "#E2E8F0", fontSize: 14, fontWeight: "800" }, newConversation: { width: 32, height: 32, borderRadius: 10, backgroundColor: "#6D45D5", alignItems: "center", justifyContent: "center" }, signInCard: { alignItems: "flex-start", backgroundColor: "#17112B", borderRadius: 12, padding: 12, gap: 8 }, signInText: { color: "#C4B5FD", fontSize: 12, lineHeight: 18 }, signInButton: { backgroundColor: "#A78BFA", borderRadius: 9, paddingHorizontal: 12, paddingVertical: 8 }, signInButtonText: { color: "#080B12", fontSize: 12, fontWeight: "800" }, historyList: { gap: 2 }, historyRow: { flexDirection: "row", alignItems: "center", gap: 9, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "#1C283C" }, messageActions: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 9 }, messageAction: { width: 26, height: 26, borderRadius: 8, backgroundColor: "#182235", alignItems: "center", justifyContent: "center" }, historySearch: { color: "#E2E8F0", backgroundColor: "#111827", borderRadius: 10, borderWidth: 1, borderColor: "#25324A", paddingHorizontal: 10, paddingVertical: 8, fontSize: 12, marginBottom: 8 }, modelRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: "#1C283C" }, modelRadio: { width: 18, height: 18, borderRadius: 9, borderWidth: 1, borderColor: "#64748B", alignItems: "center", justifyContent: "center" }, modelRadioActive: { borderColor: "#A78BFA" }, modelRadioDot: { width: 9, height: 9, borderRadius: 5, backgroundColor: "#A78BFA" }, processingRow: { flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 20, paddingBottom: 8 }, processingText: { color: "#A78BFA", fontSize: 12 },
});
