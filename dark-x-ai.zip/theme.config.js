/** @type {const} */
const themeColors = {
  primary: { light: '#6D45D5', dark: '#A78BFA' },
  background: { light: '#F8FAFC', dark: '#080B12' },
  surface: { light: '#FFFFFF', dark: '#111827' },
  foreground: { light: '#111827', dark: '#F4F7FB' },
  muted: { light: '#64748B', dark: '#94A3B8' },
  border: { light: '#E2E8F0', dark: '#25324A' },
  success: { light: '#16A34A', dark: '#34D399' },
  warning: { light: '#D97706', dark: '#F59E0B' },
  error: { light: '#E11D48', dark: '#FB7185' },
};

module.exports = { themeColors };
