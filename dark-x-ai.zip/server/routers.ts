import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import * as platformDb from "./platform-db";
import { z } from "zod";
import { answerWithOrchestration } from "./services/ai-orchestrator";
import { listLLMModels } from "./_core/llm";
import { AGENT_REGISTRY, runApprovedAgent } from "./services/agent-registry";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  ai: router({
    answer: publicProcedure
      .input(z.object({ message: z.string().trim().min(1).max(8000), context: z.string().trim().max(12000).optional(), conversationId: z.number().int().positive().optional(), model: z.string().trim().max(160).optional() }))
      .mutation(({ ctx, input }) => answerWithOrchestration({ ...input, userId: ctx.user?.id })),
    models: publicProcedure.query(async () => {
      const response = await listLLMModels();
      return response.data.map(({ id, owned_by }) => ({ id, ownedBy: owned_by }));
    }),
  }),
  workspaces: router({
    list: protectedProcedure.query(({ ctx }) => platformDb.listWorkspaces(ctx.user.id)),
    create: protectedProcedure
      .input(z.object({ name: z.string().trim().min(1).max(160), description: z.string().trim().max(2000).optional() }))
      .mutation(({ ctx, input }) => platformDb.createWorkspace(ctx.user.id, input.name, input.description)),
  }),
  projects: router({
    list: protectedProcedure.query(({ ctx }) => platformDb.listProjects(ctx.user.id)),
  }),
  conversations: router({
    list: protectedProcedure.query(({ ctx }) => platformDb.listConversations(ctx.user.id)),
    create: protectedProcedure
      .input(z.object({ title: z.string().trim().min(1).max(200), workspaceId: z.number().int().positive().optional(), projectId: z.number().int().positive().optional() }))
      .mutation(({ ctx, input }) => platformDb.createConversation(ctx.user.id, input)),
    messages: protectedProcedure
      .input(z.object({ conversationId: z.number().int().positive() }))
      .query(({ ctx, input }) => platformDb.listMessages(ctx.user.id, input.conversationId)),
  }),
  agents: router({
    list: protectedProcedure.query(() => AGENT_REGISTRY),
    run: protectedProcedure
      .input(z.object({ agentId: z.string().min(1).max(80), task: z.string().trim().min(1).max(8000) }))
      .mutation(({ input }) => runApprovedAgent(input.agentId, input.task)),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
