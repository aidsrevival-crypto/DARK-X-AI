import { desc, eq } from "drizzle-orm";
import { getDb } from "./db";
import {
  aiUsage,
  conversations,
  messages,
  projects,
  workspaces,
  type InsertUser,
} from "../drizzle/schema";

export async function listWorkspaces(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(workspaces).where(eq(workspaces.userId, userId)).orderBy(desc(workspaces.updatedAt));
}

export async function createWorkspace(userId: number, name: string, description?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(workspaces).values({ userId, name, description });
  return Number(result[0].insertId);
}

export async function listProjects(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ project: projects, workspace: workspaces })
    .from(projects)
    .innerJoin(workspaces, eq(projects.workspaceId, workspaces.id))
    .where(eq(workspaces.userId, userId))
    .orderBy(desc(projects.updatedAt));
}

export async function listConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(conversations).where(eq(conversations.userId, userId)).orderBy(desc(conversations.updatedAt));
}

export async function createConversation(userId: number, input: { title: string; workspaceId?: number; projectId?: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(conversations).values({ userId, title: input.title, workspaceId: input.workspaceId, projectId: input.projectId });
  return Number(result[0].insertId);
}

export async function listMessages(userId: number, conversationId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ message: messages, conversation: conversations })
    .from(messages)
    .innerJoin(conversations, eq(messages.conversationId, conversations.id))
    .where(eq(conversations.userId, userId))
    .orderBy(messages.createdAt);
}

export async function addMessage(input: { conversationId: number; userId?: number; role: "system" | "user" | "assistant" | "tool"; content: string; sourcesJson?: string; metadataJson?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(messages).values(input);
}

export async function recordUsage(input: { userId: number; conversationId?: number; route: string; model?: string; promptTokens?: number; completionTokens?: number; searchCredits?: number }) {
  const db = await getDb();
  if (!db) return;
  await db.insert(aiUsage).values(input);
}
