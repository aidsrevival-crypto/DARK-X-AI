export type ModelTask = "chat" | "reasoning" | "vision" | "long-context" | "tool-calling" | "embedding";

export type ModelRoute = {
  provider: "manus-forge";
  model?: string;
  task: ModelTask;
};

/**
 * Central routing policy. The built-in provider resolves the concrete model when
 * no model override is supplied, so application code stays provider-agnostic.
 */
export function resolveModel(task: ModelTask, model?: string): ModelRoute {
  return { provider: "manus-forge", task, model: model?.trim() || undefined };
}
