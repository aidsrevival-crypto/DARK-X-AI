import { invokeLLM } from "../_core/llm";
import { searchWeb, type TavilySearchResult } from "./tavily";
import { addMessage, createConversation, recordUsage } from "../platform-db";
import { resolveModel } from "./model-router";

export type AnswerRequest = {
  message: string;
  context?: string;
  userId?: number;
  conversationId?: number;
  model?: string;
};

export type AnswerSource = Pick<TavilySearchResult, "title" | "url" | "favicon" | "score">;

export type AnswerResponse = {
  answer: string;
  route: "knowledge" | "live-search";
  sources: AnswerSource[];
  status: "complete";
  conversationId?: number;
};

const LIVE_QUERY_PATTERN = /\b(latest|current|today|tonight|this week|this month|recent|news|release|releases|price|prices|weather|score|scores|exchange rate|what happened|as of)\b/i;

export function needsWebSearch(message: string) {
  return LIVE_QUERY_PATTERN.test(message);
}

function formatSources(results: TavilySearchResult[]) {
  return results
    .map((result, index) => `[${index + 1}] ${result.title}\nURL: ${result.url}\nContent: ${result.content}`)
    .join("\n\n");
}

export async function answerWithOrchestration(request: AnswerRequest): Promise<AnswerResponse> {
  const useSearch = needsWebSearch(request.message);
  const route = resolveModel(useSearch ? "tool-calling" : "chat", request.model);
  const search = useSearch ? await searchWeb(request.message) : undefined;
  const sourceContext = search?.results.length
    ? `\n\nLIVE SOURCES (cite only these URLs when making current claims):\n${formatSources(search.results)}`
    : "";
  const context = request.context?.trim()
    ? `\n\nUSER-PROVIDED CONTEXT:\n${request.context.trim()}`
    : "";

  const llmResponse = await invokeLLM({
    messages: [
      {
        role: "system",
        content:
          "You are DARK X AI, a precise AI workspace assistant. Answer clearly and honestly. Never reveal private chain-of-thought. When live sources are provided, ground current claims in those sources and add compact [n] citations matching the source list. If the sources do not support a claim, say that the information is unavailable or uncertain. Do not invent citations or URLs.",
      },
      { role: "user", content: `${request.message}${context}${sourceContext}` },
    ],
    model: route.model,
    maxTokens: 1200,
  });

  const content = llmResponse.choices?.[0]?.message?.content;
  const answer = Array.isArray(content)
    ? content.filter((part) => part.type === "text").map((part) => part.text).join("\n")
    : content;

  if (!answer?.trim()) {
    throw new Error("The AI provider returned an empty response.");
  }

  let conversationId = request.conversationId;
  if (request.userId) {
    conversationId ??= await createConversation(request.userId, { title: request.message.slice(0, 72) });
    await addMessage({ conversationId, userId: request.userId, role: "user", content: request.message });
    await addMessage({ conversationId, userId: request.userId, role: "assistant", content: answer.trim(), sourcesJson: JSON.stringify(search?.results ?? []) });
    await recordUsage({ userId: request.userId, conversationId, route: useSearch ? "live-search" : "knowledge", model: llmResponse.model ?? route.model, promptTokens: llmResponse.usage?.prompt_tokens, completionTokens: llmResponse.usage?.completion_tokens, searchCredits: search?.results.length ?? 0 });
  }

  return {
    answer: answer.trim(),
    route: useSearch ? "live-search" : "knowledge",
    sources: search?.results.map(({ title, url, favicon, score }) => ({ title, url, favicon, score })) ?? [],
    status: "complete",
    conversationId,
  };
}
