import { ENV } from "../_core/env";

export type TavilySearchResult = {
  title: string;
  url: string;
  content: string;
  score: number;
  favicon?: string;
  published_date?: string;
};

export type TavilySearchResponse = {
  query: string;
  results: TavilySearchResult[];
  answer?: string | null;
};

type TavilyApiResponse = {
  query?: unknown;
  answer?: unknown;
  results?: unknown;
};

const TAVILY_SEARCH_URL = "https://api.tavily.com/search";

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function normalizeResult(value: unknown): TavilySearchResult | null {
  if (!isRecord(value)) return null;
  const title = typeof value.title === "string" ? value.title : "";
  const url = typeof value.url === "string" ? value.url : "";
  const content = typeof value.content === "string" ? value.content : "";
  const score = typeof value.score === "number" ? value.score : 0;
  if (!title || !url || !content) return null;

  return {
    title,
    url,
    content,
    score,
    ...(typeof value.favicon === "string" ? { favicon: value.favicon } : {}),
    ...(typeof value.published_date === "string" ? { published_date: value.published_date } : {}),
  };
}

export async function searchWeb(query: string): Promise<TavilySearchResponse> {
  const normalizedQuery = query.trim();
  if (!normalizedQuery) throw new Error("A web search query is required.");
  if (!ENV.tavilyApiKey) {
    throw new Error("Live web search is not configured. Set TAVILY_API_KEY on the server.");
  }

  const response = await fetch(TAVILY_SEARCH_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${ENV.tavilyApiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      query: normalizedQuery,
      search_depth: "advanced",
      max_results: 5,
      include_answer: false,
      include_raw_content: false,
      include_favicon: true,
    }),
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`Live web search failed (${response.status}).${detail ? ` ${detail.slice(0, 240)}` : ""}`);
  }

  const payload = (await response.json()) as TavilyApiResponse;
  const results = Array.isArray(payload.results)
    ? payload.results.map(normalizeResult).filter((result): result is TavilySearchResult => result !== null)
    : [];

  return {
    query: typeof payload.query === "string" ? payload.query : normalizedQuery,
    results,
    answer: typeof payload.answer === "string" ? payload.answer : null,
  };
}
