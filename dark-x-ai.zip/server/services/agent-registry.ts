import { searchWeb, type TavilySearchResponse } from "./tavily";

export type ApprovedTool = "web_search" | "calculator";

export type AgentDefinition = {
  id: string;
  name: string;
  description: string;
  allowedTools: ApprovedTool[];
};

export const AGENT_REGISTRY: AgentDefinition[] = [
  {
    id: "research-analyst",
    name: "Research analyst",
    description: "Finds recent information and returns grounded sources.",
    allowedTools: ["web_search"],
  },
  {
    id: "clarity-editor",
    name: "Clarity editor",
    description: "Prepares concise output without external tool access.",
    allowedTools: [],
  },
];

export function getAgent(agentId: string) {
  const agent = AGENT_REGISTRY.find((item) => item.id === agentId);
  if (!agent) throw new Error("Agent is not registered.");
  return agent;
}

export async function runApprovedAgent(agentId: string, task: string) {
  const agent = getAgent(agentId);
  if (agent.allowedTools.includes("web_search")) {
    const search: TavilySearchResponse = await searchWeb(task);
    return {
      agent,
      status: "completed" as const,
      summary: `Research completed for: ${task}`,
      sources: search.results.map(({ title, url, favicon, score }) => ({ title, url, favicon, score })),
    };
  }

  return {
    agent,
    status: "completed" as const,
    summary: `Task accepted by ${agent.name}. No external tools were required.`,
    sources: [],
  };
}
