# DARK X AI Mobile Interface Design

## Product direction

DARK X AI is a premium, dark-first AI command center for mobile. The first mobile release prioritizes fast entry into an AI conversation, visibility into active context, and discoverability of projects, agents, files, and tools without overwhelming the user. The experience is designed for portrait orientation and one-handed use, with short, high-confidence actions and clear progressive disclosure.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| Home / Command Center | Greeting, global search, current workspace summary, suggested prompts, recent conversations, active projects, and quick actions for starting a chat or attaching context. |
| Chat | Conversation header, model/context selector, message timeline, safe status events such as searching or analyzing, composer with attachment and voice affordances, copy/regenerate actions, and source chips when live information is used. |
| Projects | Project list with health/status, pinned knowledge, recent activity, and entry points into project-specific chat and files. |
| Agents | Agent catalog showing purpose, allowed tools, and current run state; launching an agent opens a task composer with a visible plan/status timeline. |
| Files & Knowledge | Local/project files, indexed knowledge sources, upload/import entry point, and retrieval scope controls. |
| Settings | Profile/session status, appearance, default model preference, data controls, notifications, and connected capability summaries. |

## Key user flows

### Start a conversation

1. The user opens Home and taps the primary composer or a suggested prompt.
2. The app opens Chat with the prompt prefilled and the selected context visible.
3. The user sends the request and sees safe progress states such as “Understanding request,” “Searching,” and “Preparing answer.”
4. The response appears in a readable message card with optional source chips and actions for copy, retry, regenerate, or continue.

### Use project context

1. The user taps a project from Home or Projects.
2. The project detail view shows its knowledge scope, recent conversations, and pinned files.
3. The user starts a project chat; the composer indicates that the project context is active.
4. The user can remove or change context from the chat header without leaving the conversation.

### Launch an approved agent

1. The user opens Agents and selects an agent card.
2. The task composer explains the agent’s purpose and allowed tools.
3. The user submits a task and sees a compact status timeline, never hidden chain-of-thought.
4. The completed run exposes outputs, sources, and a concise execution summary.

## Visual system

The palette is inspired by a midnight operations console rather than a generic chatbot. The base canvas is near-black navy `#080B12`, elevated surfaces are `#111827` and `#182235`, and borders are cool slate `#25324A`. Primary text is `#F4F7FB`; secondary text is `#94A3B8`. The brand accent is electric violet `#8B5CF6`, with cyan `#22D3EE` reserved for live intelligence and mint `#34D399` for successful tool or agent states. Warning and error states use amber `#F59E0B` and coral `#FB7185` sparingly.

Cards use 16–20 px corner radii, 1 px low-contrast borders, and restrained shadows. Primary actions use a violet-to-cyan visual emphasis only where needed. Typography is compact and editorial: large page titles, medium-weight section labels, and comfortable 15–16 px message text. The bottom tab bar remains translucent and visually quiet so the active workspace stays dominant.

## Interaction principles

The most important action is always reachable in the lower half of the screen. Pressable controls provide opacity or scale feedback and haptics only for primary actions. Long content uses virtualized lists; sheets and inline panels provide progressive disclosure instead of full-screen navigation whenever the task is lightweight. Every asynchronous state provides feedback, and destructive actions require confirmation.

## First implementation slice

The first build will implement Home as a functional command center, a local-first Chat flow with seeded conversation state, interactive suggested prompts, model/context controls, recent activity, and the main navigation surfaces for Projects, Agents, and Settings. Backend and provider integrations remain behind clear capability boundaries so the UI can later connect to the scaffold’s server-side LLM and storage features without a redesign.

## Assumptions

The attached specification describes a broad platform, while this mobile delivery is intentionally scoped to the highest-value first slice. Local state is preferred for the initial interaction model because cross-device sync and accounts were not explicitly required for the first mobile build. The app will not expose private chain-of-thought, and any live-information UI will communicate source attribution rather than inventing citations.

## Acceptance criteria

The user can launch the app, understand the product within one screen, begin a conversation, select context, see a useful seeded response, navigate between the primary surfaces, and receive clear feedback from interactive controls. The app uses the DARK X AI brand consistently, respects portrait safe areas, and contains no dead-end primary buttons.
