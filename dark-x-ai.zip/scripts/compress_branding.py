from PIL import Image
from pathlib import Path

root = Path('/home/ubuntu/dark-x-ai/assets/images')
for name in ['icon.png', 'splash-icon.png', 'favicon.png', 'android-icon-foreground.png']:
    path = root / name
    image = Image.open(path).convert('RGB')
    image.thumbnail((512, 512), Image.Resampling.LANCZOS)
    image.save(path, format='PNG', optimize=True, compress_level=9)
