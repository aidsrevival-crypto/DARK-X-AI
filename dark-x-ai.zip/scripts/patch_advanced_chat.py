from pathlib import Path
import re

path = Path('/home/ubuntu/dark-x-ai/app/(tabs)/index.tsx')
text = path.read_text()
text = text.replace('onSelectConversation, onNewConversation }: any)', 'onSelectConversation, onNewConversation, onCopy, onShare, onRegenerate }: any)')
old = '<Text style={styles.messageText}>{item.text}</Text>{item.sources?.map((source: string) => <View key={source} style={styles.sourceChip}><MaterialIcons name="verified" size={13} color="#22D3EE" /><Text style={styles.sourceText}>{source}</Text></View>)}</View></View>}'
new = '<Text style={styles.messageText}>{item.text}</Text>{item.sources?.map((source: string) => <Pressable key={source} style={styles.sourceChip} onPress={() => Alert.alert("Source", source)}><MaterialIcons name="verified" size={13} color="#22D3EE" /><Text style={styles.sourceText}>{source}</Text></Pressable>)}{item.role === "assistant" && item.id !== "welcome" && <View style={styles.messageActions}><Pressable accessibilityLabel="Copy response" onPress={() => onCopy(item.text)} style={styles.messageAction}><MaterialIcons name="content-copy" size={14} color="#94A3B8" /></Pressable><Pressable accessibilityLabel="Regenerate response" onPress={onRegenerate} style={styles.messageAction}><MaterialIcons name="refresh" size={15} color="#94A3B8" /></Pressable><Pressable accessibilityLabel="Share response" onPress={() => onShare(item.text)} style={styles.messageAction}><MaterialIcons name="ios-share" size={15} color="#94A3B8" /></Pressable></View>}</View></View>}'
if old not in text:
    raise SystemExit('message bubble segment was not found')
text = text.replace(old, new, 1)
text = text.replace('function HistoryDrawer({ history, isAuthenticated, authLoading, onLogin, onSelectConversation, onNewConversation }: any) {\n  return', 'function HistoryDrawer({ history, isAuthenticated, authLoading, onLogin, onSelectConversation, onNewConversation }: any) {\n  const [query, setQuery] = useState("");\n  const filtered = history.filter((item: { title: string }) => item.title.toLowerCase().includes(query.toLowerCase()));\n  return')
text = text.replace('<View style={styles.historyDrawer}><View style={styles.drawerHeader}>', '<View style={styles.historyDrawer}><View style={styles.drawerHeader}>')
text = text.replace('</View>{authLoading ? <Text style={styles.emptyText}>Checking your session…</Text>', '</View>{isAuthenticated && <TextInput accessibilityLabel="Search conversations" placeholder="Search conversations" placeholderTextColor="#64748B" value={query} onChangeText={setQuery} style={styles.historySearch} />}{authLoading ? <Text style={styles.emptyText}>Checking your session…</Text>')
text = text.replace('history.length === 0 ? <Text style={styles.emptyText}>No saved conversations yet.</Text> : <View style={styles.historyList}>{history.slice(0, 8).map', 'filtered.length === 0 ? <Text style={styles.emptyText}>No matching conversations.</Text> : <View style={styles.historyList}>{filtered.slice(0, 8).map')
path.write_text(text)
