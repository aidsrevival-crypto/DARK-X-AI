# DARK X AI platform architecture

## Implemented boundary

The current project keeps the mobile client thin and routes AI work through the server’s tRPC boundary. The `ai.answer` procedure validates the request, selects a route through the model-router boundary, optionally retrieves live sources through Tavily, invokes the server-side built-in LLM, and returns a grounded answer with citation metadata. Provider credentials remain server-side.

## Service choices

The built-in server-side LLM is the primary AI provider because it is already provisioned by the mobile scaffold and does not require an additional user-supplied AI key. Tavily is the external live-search provider because it returns current ranked results and citation-ready URLs. Object storage uses the scaffold’s existing server-side storage abstraction; no additional storage credential is required for this slice.

## Domain model

The database schema now includes user-scoped workspaces, projects, conversations, messages, files, knowledge chunks, memories, agents, tool executions, and AI usage. The knowledge-chunk model stores embedding payloads as a replaceable serialized field so a future embedding provider or native vector column can be introduced without changing the file and retrieval vocabulary.

The scaffold currently uses Drizzle with MySQL-compatible storage rather than PostgreSQL/pgvector. The migration therefore creates relational tables and an embedding-ready boundary without pretending that native pgvector search is already present. A future PostgreSQL migration should replace the serialized embedding field with a vector type and add an indexed semantic-retrieval query.

## Agent and tool safety

The agent registry is explicit and allow-listed. Each agent declares its approved tools, and unknown agent IDs are rejected. The first registered research agent can call the Tavily search abstraction; other agents have no external tool access by default. User-facing progress should expose safe lifecycle states, not private chain-of-thought.

## Authentication and data ownership

Workspace, project, conversation, message, and agent procedures use protected tRPC procedures and scope reads to the authenticated user. The general AI procedure remains available as a public procedure for the existing first-run mobile experience; authenticated calls can now create a conversation, save user and assistant messages, and record usage. This public mode should be rate-limited or changed to protected access before broad public launch.

## Deferred work

True token streaming over SSE/WebSockets, asynchronous file extraction, embeddings, semantic retrieval, Redis-backed queues/rate limiting, and full file-upload UI remain separate follow-up milestones. They were not silently replaced with fake results. The current implementation provides the backend vocabulary and safe extension points needed to add them incrementally.
