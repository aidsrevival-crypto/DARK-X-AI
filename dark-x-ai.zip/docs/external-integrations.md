# DARK X AI external integrations

## Selected services

DARK X AI uses the platform’s built-in server-side LLM for the main AI provider. This avoids introducing a second model API key, keeps provider credentials out of the mobile bundle, and preserves a replaceable orchestration boundary through `server/services/ai-orchestrator.ts`.

For real-time web information, DARK X AI uses **Tavily Search API**. Tavily was selected because its API is designed for AI search and RAG workflows, supports a simple REST search endpoint, returns ranked source results with URLs and content, and provides a developer signup path with a free monthly credit allowance documented in its official quickstart.

## Required credential

| Environment variable | Service | Where to obtain it | Used by |
|---|---|---|---|
| `TAVILY_API_KEY` | Tavily Search API | [Tavily Platform](https://app.tavily.com) → create/sign in → API keys | Backend-only live search and source attribution |

The key is sent to Tavily as `Authorization: Bearer <TAVILY_API_KEY>`. It must remain in secure backend environment variables and must never be placed in the Expo client, source code, or public configuration.

## Current flow

The mobile composer calls the `ai.answer` tRPC procedure. The server applies a conservative current-information heuristic. Queries containing terms such as “latest,” “current,” “today,” “news,” “price,” or “weather” route through Tavily first. The orchestrator then sends the retrieved source context to the built-in server-side LLM with instructions to ground current claims and emit compact source references. The mobile UI renders the returned answer and source titles, while the server retains the canonical URLs.

Non-current questions skip web search and go directly to the built-in LLM. If Tavily is unavailable or its secret is missing, the server returns a clear configuration error instead of inventing search results or citations.

## Validation

The project includes `tests/tavily.credentials.test.ts`, which calls Tavily’s lightweight usage endpoint with the configured secret. The test passed during integration. TypeScript, lint, and the project test suite also pass; the scaffold’s pre-existing auth test remains skipped because it depends on the platform auth harness.

## Deliberate scope boundary

This integration slice does not yet add a new external PostgreSQL, Redis, Cloudinary, or third-party AI key. The mobile scaffold already provides server-side LLM, database, and object-storage boundaries. Those services should be extended only when the associated product workflow—persistent conversations, file ingestion, vector retrieval, queues, or uploads—is implemented end-to-end.

## Official references

- [Tavily Quickstart](https://docs.tavily.com/documentation/quickstart)
- [Tavily Search API Reference](https://docs.tavily.com/documentation/api-reference/endpoint/search)
- [Tavily Platform](https://app.tavily.com)
