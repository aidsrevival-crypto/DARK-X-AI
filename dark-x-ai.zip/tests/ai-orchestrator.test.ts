import { describe, expect, it } from "vitest";
import { needsWebSearch } from "../server/services/ai-orchestrator";

describe("AI orchestration routing", () => {
  it("routes current-information prompts to live search", () => {
    expect(needsWebSearch("What is the latest release of Expo?"),).toBe(true);
    expect(needsWebSearch("What is the weather today?"),).toBe(true);
  });

  it("keeps stable knowledge prompts on the normal model route", () => {
    expect(needsWebSearch("Explain vector embeddings in simple terms."),).toBe(false);
  });
});
