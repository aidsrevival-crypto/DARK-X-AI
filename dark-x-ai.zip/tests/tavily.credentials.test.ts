import { describe, expect, it } from "vitest";

describe.skipIf(!process.env.TAVILY_API_KEY)("Tavily credentials", () => {
  it("authenticates against the Tavily usage endpoint", async () => {
    const apiKey = process.env.TAVILY_API_KEY as string;

    const response = await fetch("https://api.tavily.com/usage", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });

    expect(response.status, await response.text()).toBe(200);
  }, 15000);
});
